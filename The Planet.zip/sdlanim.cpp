#include <iostream>
//#include "stdafx.h"
#include <SDL.h>
#include <SDL_image.h>
#include <chrono>
#include "Scene1.h"
#include "Menu.h"


using namespace std;
using namespace brightland;



int main(int argc, char* argv[])
{

   // Menu m;
  //  m.menu();

    Scene1 id;
    id.scene1();
    return 0;
}