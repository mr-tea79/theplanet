#pragma once
#ifndef _SDLANIM_H_
#define _SDLANIM_H_

namespace brightland {



	class Sdladim {
	public:
				
		void initialize();
		int playGame();
		int cleanup();

	};
	


}
#endif